# exo_horoscope
Exoplanet-based horoscope
