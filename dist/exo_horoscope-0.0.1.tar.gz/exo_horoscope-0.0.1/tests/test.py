import main
main.User("Chelsea", "Redlands California", 1991, 4, 27, 12, 4, 0).get_horoscope()